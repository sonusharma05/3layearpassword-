package com.example.passcode;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.BreakIterator;

public class layer3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layer3);
        Spinner spinner_question = findViewById(R.id.spinner_security);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.questions, R.layout.selecteditem);
        adapter.setDropDownViewResource(R.layout.dropdown);
        spinner_question.setAdapter(adapter);
    }
    public boolean compareStringsUsingEquals(String str1, String str2) {
        if (str1 == null && str2 == null) {
            return true; // Both strings are null and, therefore, equal.
        }
        if (str1 == null || str2 == null) {
            return false; // One of the strings is null, so they are not equal.
        }
        return str1.equals(str2);
    }


    public void update_text(View view) {
        EditText input_text;
        input_text = (EditText) findViewById(R.id.input);

        String a=input_text.getText().toString();
        String dog= "bruno";
        String school ="DPS";
        String nickname = "sam";
        Boolean j = compareStringsUsingEquals(a,dog);
        Boolean k= compareStringsUsingEquals(a,school);
        Boolean l = compareStringsUsingEquals(a,nickname);


        if(j||k||l) {
            Intent intent_passcode = new Intent(layer3.this, ProgramActivity.class);
            startActivity(intent_passcode);
            Toast.makeText(getApplicationContext(),"welcome to the gallery", Toast.LENGTH_LONG).show();



        }
        else{
            Toast.makeText(getApplicationContext(), "wrong", Toast.LENGTH_LONG).show();

        }

    }
}